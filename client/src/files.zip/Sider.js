import React from 'react'

function Sider() {
  return (
    <div>Sider</div>
  )
}

export default Sider